'use strict';
export const BaseUrl="http://192.168.100.19/property_mgmt/api/";
export const Url="http://192.168.100.19/property_mgmt/";
export const baseurl="http://192.168.100.19/property_mgmt/RequestApi/";
// export const BaseUrl="https://www.volatron.com/property_mgmt/api/";
// export const Url="https://www.volatron.com/property_mgmt/";
// export const baseurl="https://www.volatron.com/property_mgmt/RequestApi/";

// export const Url="http://portfolio.theaxontech.com/CI/property_management/php_server/";
// export const BaseUrl="http://portfolio.theaxontech.com/CI/property_management/php_server/api/";
// export const baseurl="http://portfolio.theaxontech.com/CI/property_management/php_server/RequestApi/";
//export const BaseUrl="php_server/api/"; 
