import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tenant-payment',
  templateUrl: './tenant-payment.component.html',
  styleUrls: ['./tenant-payment.component.css']
})
export class TenantPaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
