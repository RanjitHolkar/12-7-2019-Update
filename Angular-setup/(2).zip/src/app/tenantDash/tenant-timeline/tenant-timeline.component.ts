import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tenant-timeline',
  templateUrl: './tenant-timeline.component.html',
  styleUrls: ['./tenant-timeline.component.css']
})
export class TenantTimelineComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
