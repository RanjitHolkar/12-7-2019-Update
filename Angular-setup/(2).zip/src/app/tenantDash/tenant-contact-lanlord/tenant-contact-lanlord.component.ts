import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tenant-contact-lanlord',
  templateUrl: './tenant-contact-lanlord.component.html',
  styleUrls: ['./tenant-contact-lanlord.component.css']
})
export class TenantContactLanlordComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
